package com.socgen.bip.divaPrjt.main;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileHeaderCallback;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.core.io.FileSystemResource;

import com.socgen.bip.divaPrjt.util.ExtractModal;
import com.socgen.bip.divaPrjt.util.ReportConstants;

public class GenerateReport implements ItemWriter<List<ExtractModal>> {

	private static final Logger LOG = Logger.getLogger(GenerateReport.class);

	private FlatFileItemWriter<String> writerriter = new FlatFileItemWriter<String>();

	private List<String> extractList = new ArrayList<String>();

	private String reportOutPath;

	private String fileName;

	private static final String[] HEADER = { "ICPI", "ILIBEL", "STATUT", "DATDEM", "CADA", "ICODPROJ" };

	public void write(List<? extends List<ExtractModal>> extractModalList) throws Exception {

		LOG.info(GenerateReport.class + ReportConstants.START);
		LOG.info("<------Diva Project Chunk Writer Start--------->");
		LOG.info("<------Preparation of header--------->");
		try {
			writerriter.setHeaderCallback(new FlatFileHeaderCallback() {
				public void writeHeader(Writer writer) throws IOException {
					for (String header : HEADER) {
						writer.write(header);
						writer.write(";");
					}
				}
			});
			LOG.info("HEADER : " + Arrays.toString(HEADER));
			LOG.info("file Path : "+reportOutPath.trim() +  fileName);
			writerriter.setResource(new FileSystemResource(reportOutPath.trim() +  fileName));
			writerriter.setShouldDeleteIfExists(true);
			writerriter.setShouldDeleteIfEmpty(true);
			DelimitedLineAggregator<String> lineAggregator = new DelimitedLineAggregator<String>();
			writerriter.setLineAggregator(lineAggregator);
			writerriter.setLineSeparator("");

			for (ExtractModal detail : (List<ExtractModal>) extractModalList.get(0)) {
				extractList.add(ReportConstants.NEXTLINE);
				extractList.add(detail.getIcpi() + ";");
				extractList.add(detail.getIlibel() + ";");
				extractList.add(detail.getStatut() + ";");
				extractList.add(detail.getDatdem() + ";");
				extractList.add(detail.getCada() + ";");
				extractList.add(detail.getIcodproj() + ";");
				writerriter.open(new ExecutionContext());
				writerriter.write(extractList);
				extractList.clear();

			}
		} catch (Exception e) {
			throw new BatchException(e.getMessage());
		}
		LOG.info(GenerateReport.class + ReportConstants.END);
		LOG.info("<------Diva Project Chunk Writer End--------->");
	}

	public String getReportOutPath() {
		return reportOutPath;
	}

	public void setReportOutPath(String reportOutPath) {
		this.reportOutPath = reportOutPath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
