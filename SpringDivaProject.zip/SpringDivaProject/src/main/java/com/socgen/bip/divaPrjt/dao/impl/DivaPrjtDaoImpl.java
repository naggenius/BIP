package com.socgen.bip.divaPrjt.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.socgen.bip.divaPrjt.dao.BaseDAO;
import com.socgen.bip.divaPrjt.dao.DivaPrjtDao;
import com.socgen.bip.divaPrjt.main.BatchException;
import com.socgen.bip.divaPrjt.util.ExtractModal;
import com.socgen.bip.divaPrjt.util.ReportConstants;

import oracle.jdbc.internal.OracleTypes;

public class DivaPrjtDaoImpl extends BaseDAO implements DivaPrjtDao {

	/**
	 * place holder for log
	 */
	private static final Logger LOG = Logger.getLogger(DivaPrjtDaoImpl.class);

	/**
	 * Batch Exception Class Object
	 */
	/*
	 * @Autowired private BatchExceptionDao batchExceptionDao;
	 */
	@Autowired
	DataSource dataSource;

	public List<ExtractModal> getReportData() throws SQLException, BatchException {

		LOG.info(DivaPrjtDaoImpl.class + ReportConstants.START);
		List<ExtractModal> resultList = new ArrayList<ExtractModal>();
		Connection con = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;

		String pack = "{CALL PACK_DIVA.PROJETS_REPORT(?,?,?)}";
		try {
			// jdbcTemplateObject = new JdbcTemplate(dataSource);

			/*
			 * SqlParameter[] parameters = {new SqlOutParameter("P_CODE",
			 * OracleTypes.NUMBER), new SqlOutParameter("P_MSG", OracleTypes.VARCHAR), new
			 * SqlOutParameter("P_OUT_CURSOR", OracleTypes.CURSOR) }; StoredProcedure
			 * procedure = new GenericStoredProcedure();
			 * procedure.setDataSource(dataSource);
			 * procedure.setSql("PACK_DIVA.PROJETS_REPORT"); procedure.setFunction(false);
			 * procedure.setParameters(parameters); procedure.compile();
			 * 
			 * resultMap = procedure.execute();
			 */

			con = getdataSource().getConnection();
			cstmt = con.prepareCall(pack);
			cstmt.registerOutParameter(1, OracleTypes.NUMBER);
			cstmt.registerOutParameter(2, OracleTypes.VARCHAR);
			cstmt.registerOutParameter(3, OracleTypes.CURSOR);

			cstmt.execute();
			if(0==cstmt.getInt(1)) {
				rs = (ResultSet) cstmt.getObject(3);
				while (rs.next()) {
					ExtractModal modal = mapRow(rs);
					resultList.add(modal);
				}
			}

		} catch (Exception e) {
			throw new BatchException(e.getMessage() + DivaPrjtDaoImpl.class);
		}

		LOG.info(DivaPrjtDaoImpl.class + ReportConstants.END);
		return resultList;
	}

	private ExtractModal mapRow(ResultSet rs) throws SQLException {
		
		ExtractModal modal = new ExtractModal();
		
		modal.setIcpi(nullCheck(rs.getString("ICPI")));
		modal.setIlibel(nullCheck(rs.getString("ILIBEL")));
		modal.setStatut(nullCheck(rs.getString("STATUT")));
		modal.setDatdem(nullCheck(rs.getString("DATDEM")));
		modal.setCada(nullCheck(rs.getString("CADA")));
		modal.setIcodproj(nullCheck(rs.getString("ICODPROJ")));		
		return modal;
	}
	
	private String nullCheck(String s) {
		
		if(null != s && !s.isEmpty()) {
			return s;
		} else {
			return null;
		}
	}

	/**
	 * @param s
	 * @throws BatchException
	 */
	/*
	 * public void exceptionHandling(String s) throws BatchException { String[]
	 * exceptionMessage = {
	 * ResourceBundleLoader.getValue(ReportConstants.READERERRORCODE), s +
	 * DivaPrjtDaoImpl.class };
	 * batchExceptionDao.insertBatchException(exceptionMessage); }
	 */

}