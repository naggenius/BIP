package com.socgen.bip.divaPrjt.dao;

import java.sql.SQLException;
import java.util.List;

import com.socgen.bip.divaPrjt.main.BatchException;
import com.socgen.bip.divaPrjt.util.ExtractModal;

public interface DivaPrjtDao {


	List<ExtractModal> getReportData() throws SQLException, BatchException;


}
