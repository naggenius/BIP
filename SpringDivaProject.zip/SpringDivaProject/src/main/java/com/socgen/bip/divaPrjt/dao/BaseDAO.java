package com.socgen.bip.divaPrjt.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class BaseDAO {

	/**
	 * Field simpleJdbcTemplate
	 */
    private JdbcTemplate simpleJdbcTemplate;
	
    /**
	 * @return the simpleJdbcTemplate
	 */
	public final JdbcTemplate getSimpleJdbcTemplate() {
		return simpleJdbcTemplate;
	}

	/**
	 * @param simpleJdbcTemplate the simpleJdbcTemplate to set
	 */
	public final void setSimpleJdbcTemplate(final JdbcTemplate simpleJdbcTemplate) {
		this.simpleJdbcTemplate = simpleJdbcTemplate;
	}

	/**
     * Field dataSource
     */
	@Autowired
	private DataSource dataSource;
	 
	/**
	 * @return the dataSource
	 */
	public DataSource getdataSource() {
		return dataSource;
	}

	/**
	 * @param dataSource the dataSource to set
	 */
	public void setdataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * Method to set the DataSource in simpleJdbcTemplate.
	 * 
	 * @param dataSource DataSource
	 */
	public void setDataSource(DataSource dataSource) {
		this.simpleJdbcTemplate = new JdbcTemplate(dataSource);
	}

}