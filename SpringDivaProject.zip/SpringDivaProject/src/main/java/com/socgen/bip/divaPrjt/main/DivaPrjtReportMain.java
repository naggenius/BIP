package com.socgen.bip.divaPrjt.main;

import java.io.IOException;

import javax.sql.DataSource;
import javax.xml.xpath.XPathExpressionException;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.socgen.bip.divaPrjt.util.ReportConstants;
import com.socgen.bip.divaPrjt.util.ResourceBundleLoader;



@Configuration
public class DivaPrjtReportMain {
	/**
	 * Logger class for DivaPrjtReportMain
	 */
	private static final Logger LOG = Logger.getLogger(DivaPrjtReportMain.class);

	/**
	 * main method to trigger the job.
	 * @param args String[]
	 * @throws XPathExpressionException
	 *             XPathExpressionException
	 * @throws IOException 
	 * @throws BatchException 
	 */
	public static void main(String[] args) throws IOException, XPathExpressionException, BatchException  {
		 /**
		 * Field context.
		 */
		AbstractApplicationContext context = null;

		/**
		 * Field jpBuilder.
		 */
		JobParametersBuilder jpBuilder = null;

		/**
		 * Field jobLauncher.
		 */
		JobLauncher jobLauncher = null;

		/**
		 * Field reportJob.
		 */
		Job reportJob = null;
		//BasicConfigurator.configure();
		LOG.info(ReportConstants.MAIN_METHOD_START);	
		try {
			
			String reportOutPath = null;
			String fileName = null;
			
			if ((args.length == 2)) {
				reportOutPath = args[0];
				fileName = args[1];
			}else {
				reportOutPath = ResourceBundleLoader.getValue("REPORT_OUT_PATH");
				fileName = ResourceBundleLoader.getValue("EXTRACT_NAME");
			}			
			context = new ClassPathXmlApplicationContext(ReportConstants.APP_CONTEXT);
			jpBuilder = new JobParametersBuilder();
			jpBuilder.addString("reportOutPath", reportOutPath);
			jpBuilder.addString("fileName", fileName);
			reportJob = (Job) context.getBean(ReportConstants.DIVA_PRJT_BATCH);
			jobLauncher = (JobLauncher) context.getBean(ReportConstants.JOB_LAUNCHER);
			jobLauncher.run(reportJob, jpBuilder.toJobParameters());
				LOG.info(ReportConstants.MAIN_METHOD_END);

		} catch (Exception e) {
			LOG.error(ReportConstants.EXCP_OCCURED_IN+e.getClass()+ e.getMessage());	
		} finally {
			reportJob = null;
			jpBuilder = null;
			context = null;
		}
	}

	/**
	 * Field dataSource.
	 */
	@Autowired
	private DataSource dataSource;

	/**
	 * Method transactionManager
	 * 
	 * @return PlatformTransactionManager
	 */
	@Bean
	public PlatformTransactionManager transactionManager() {
		return new DataSourceTransactionManager(dataSource);
	}
	
}