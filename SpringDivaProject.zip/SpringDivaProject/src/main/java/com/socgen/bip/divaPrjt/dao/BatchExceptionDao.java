package com.socgen.bip.divaPrjt.dao;

import java.sql.SQLException;

import com.socgen.bip.divaPrjt.main.BatchException;


public interface BatchExceptionDao {

	
	 /**
	 * Method to insert only Exception details into Batch Exception Table.
	 * @param exceptionMessage String[] 
	 * @throws BatchException exception
	 * @return cnt
	 */
	 int insertBatchException(String[] exceptionMessage) throws BatchException, SQLException;

}
