package com.socgen.bip.divaPrjt.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;

import com.socgen.bip.divaPrjt.dao.BaseDAO;
import com.socgen.bip.divaPrjt.dao.BatchExceptionDao;
import com.socgen.bip.divaPrjt.main.BatchException;
import com.socgen.bip.divaPrjt.util.ReportConstants;

public class BatchExceptionDaoImpl extends BaseDAO implements BatchExceptionDao {

	/**
	 * Logger for BatchExceptionDaoImpl.
	 */
	private static final Logger LOG = Logger.getLogger(BatchExceptionDaoImpl.class);
	/*private final String batchId = ReportConstants.DIVA_PRJT_BATCH;*/
	/*private final String keyInfo = batchId+ (LocalDate.now().format(DateTimeFormatter.ofPattern("ddMMyyyy")).toString());*/	

	/**
	 * Method to insert only Exception details into Batch Exception Table.
	 * 
	 * @param exceptionMessage
	 *            String[]
	 * @throws BatchException
	 * @return cnt
	 * @throws SQLException 
	 */
	public int insertBatchException(String[] exceptionMessage) throws BatchException, SQLException {

		LOG.info(BatchExceptionDaoImpl.class + ReportConstants.START);

		int cnt = 0;
		String SQL = "insert into BATCH_LOGS_BIP (NOM_BATCH, DATEDEB, HEURE_DEB, DATEFIN, HEURE_FIN, LIBELLEORA, ECRIT, LU, STATUT) values "
				+ "('diva_projets.jar', TO_CHAR(sysdate,'DD/MM/YYYY'), TO_CHAR(sysdate,'HH24:MI:SS'),TO_CHAR(sysdate,'DD/MM/YYYY'),TO_CHAR(sysdate,'HH24:MI:SS'),?,0,0, 'NOK')";
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = getdataSource().getConnection();
			//jdbcTemplateObject.update(SQL, ReportConstants.DIVA_PRJT_BATCH+"-"+exceptionMessage[0] + "-" + exceptionMessage[1]);
			stmt=con.prepareStatement(SQL);  
			stmt.setString(1,ReportConstants.DIVA_PRJT_BATCH+"-"+exceptionMessage[0] + "-" + exceptionMessage[1]);  			  
			cnt =stmt.executeUpdate();  
			LOG.info("count:" + cnt);
		} catch (DataAccessException dataAccessException) {
			LOG.error(dataAccessException.getMessage());
		} catch (Exception exception) {
			LOG.error(exception.getMessage());
		} finally {
			stmt.close();
			con.close();
			
		}

		LOG.info(BatchExceptionDaoImpl.class + ReportConstants.END);
		return cnt;

	}

}