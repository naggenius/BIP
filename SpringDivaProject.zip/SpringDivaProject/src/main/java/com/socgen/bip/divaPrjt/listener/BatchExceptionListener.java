package com.socgen.bip.divaPrjt.listener;


import org.apache.log4j.Logger;
import org.springframework.batch.core.listener.ItemListenerSupport;

import com.socgen.bip.divaPrjt.dao.BatchExceptionDao;
import com.socgen.bip.divaPrjt.util.ReportConstants;
import com.socgen.bip.divaPrjt.util.ResourceBundleLoader;


public class BatchExceptionListener extends ItemListenerSupport<Object, Object> {
	
	private static final Logger LOG = Logger.getLogger(BatchExceptionListener.class);
	
	/**
	 * Dao object to call the database related methods.
	 */
	private BatchExceptionDao batchExceptionDao;
		
	/**
     * Method will be called any exception during Reader
     * @param  ex Exception
     * @return  
     */
	@Override
	public void onReadError(Exception ex) {
			LOG.info(ReportConstants.INSIDE_READER);
			LOG.error(ReportConstants.EXCEP_OCC_IN_READER, ex);
		String[] exceptionMessage = {ResourceBundleLoader.getValue(ReportConstants.READERERRORCODE),ex.getMessage()};
		try {
			batchExceptionDao.insertBatchException(exceptionMessage);
			
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
	}

	/**
	 * Method will be called any exception during Write
	 * 
	 * @param  ex Exception
	 * @param  item java.util.List
	 * @return
	 */
	@Override
	public void onWriteError(Exception ex, java.util.List<?> item) {
			LOG.info(ReportConstants.INSIDE_WRITER);
			LOG.error(ReportConstants.EXCEP_OCC_IN_WRITER, ex);
		String[] exceptionMessage = {ResourceBundleLoader.getValue(ReportConstants.WRITERERRORCODE),ex.getMessage()};
		try {
			batchExceptionDao.insertBatchException(exceptionMessage);
			
		} catch (Exception e) {
			LOG.error(e.getMessage());
		}
		}

	/**
	 * @return the batchExceptionDao
	 */
	public BatchExceptionDao getBatchExceptionDao() {
		return batchExceptionDao;
	}

	/**
	 * @param batchExceptionDao the batchExceptionDao to set
	 */
	public void setBatchExceptionDao(BatchExceptionDao batchExceptionDao) {
		this.batchExceptionDao = batchExceptionDao;
	}

}
