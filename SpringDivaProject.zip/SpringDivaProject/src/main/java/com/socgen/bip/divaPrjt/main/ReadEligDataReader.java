package com.socgen.bip.divaPrjt.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import com.socgen.bip.divaPrjt.dao.DivaPrjtDao;
import com.socgen.bip.divaPrjt.util.ExtractModal;
import com.socgen.bip.divaPrjt.util.ReportConstants;

public class ReadEligDataReader implements ItemReader<List<ExtractModal>> {

	private static final Logger LOG = Logger.getLogger(ReadEligDataReader.class);

	private DivaPrjtDao divaDao;
	
	private static boolean chunkFlag = true;

	public List<ExtractModal> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		List<ExtractModal> extractModalList = new ArrayList<ExtractModal>();
		if(chunkFlag) {
			LOG.info(ReadEligDataReader.class + ReportConstants.START);
			LOG.info("<------Diva Project Chunk Reader Start--------->");
			try {
				extractModalList = divaDao.getReportData();
			} catch (SQLException e) {			
				LOG.error(e.getMessage());
				throw new BatchException(e.getMessage());
			} catch (BatchException e) {
				throw new BatchException(e.getMessage());
			}
			LOG.info("<------Diva Project Chunk Reader End--------->");
			chunkFlag = false;
			LOG.info(ReadEligDataReader.class + ReportConstants.END);
			return extractModalList;			
		}
		return null;
		
	}
	
	public DivaPrjtDao getDivaDao() {
		return divaDao;
	}

	public void setDivaDao(DivaPrjtDao divaDao) {
		this.divaDao = divaDao;
	}
}
