package com.socgen.bip.divaPrjt.main;

import java.io.PrintWriter;
import java.io.StringWriter;


public class BatchException extends Exception {

	private static final long serialVersionUID = 1L;

	private int mErrorCode = -1;

	/**
	 * Constructor BatchException
	 */
	public BatchException() {
		super();
	}

	/**
	 * Constructor BatchException
	 * 
	 * @param message String
	 */
	public BatchException(String message) {
		super(message);
	}

	/**
	 * Constructor BatchException
	 * 
	 * @param cause  Throwable
	 */
	public BatchException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructor BatchException
	 * 
	 * @param message String 
	 * @param cause Throwable
	 */
	public BatchException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * Constructor BatchException
	 * 
	 * @param message String 
	 * @param errorCode int 
	 */
	public BatchException(String message, int errorCode) {
		super(message);
		mErrorCode = errorCode;

	}

	/**
	 * Constructor BatchException
	 * 
	 * @param cause Throwable
	 * @param errorCode int
	 */
	public BatchException(Throwable cause, int errorCode) {
		super(cause);
		mErrorCode = errorCode;

	}

	/**
	 * Constructor BatchException
	 * 
	 * @param message String
	 * @param cause Throwable
	 * @param errorCode int
	 */
	public BatchException(String message, Throwable cause, int errorCode) {
		super(message, cause);
		mErrorCode = errorCode;

	}

	/**
	 * Get the detailed error message
	 * 
	 * @return messageBuffer StringBuffer
	 */
	public final StringBuffer getDetailedMessage() {
		String message = getMessage();
		StringBuffer messageBuffer = new StringBuffer(message);

		if (message == null) {
			messageBuffer = messageBuffer.append(' ');
			
		}

		if (mErrorCode != -1) {
			messageBuffer = messageBuffer.append(" [ error code = " + mErrorCode + "]");
			
		}

		Throwable cause = getCause();

		if (cause != null && cause != this) {

			String causeMessage = cause.getMessage();
			if (causeMessage != null) {
				messageBuffer = messageBuffer.append(' ');
				messageBuffer = messageBuffer.append(causeMessage);
				
			}

			String stackTraceString = getMessageStackString(cause);
			messageBuffer = messageBuffer.append('\n');
			messageBuffer = messageBuffer.append(stackTraceString);
			
		}
		return messageBuffer;
	}
	/**
	 * 
	 * @return mErrorCode - error code
	 */

	public final int getErrorCode() {
		return mErrorCode;
	}
	/**
	 * @param defValue int
	 * @return mErrorCode - error code
	 */

	public final int getErrorCode(int defValue) {
		return mErrorCode;
	}
	/**
	 * @param errorCode int
	 * 
	 */

	public final void setErrorCode(int errorCode) {
		mErrorCode = errorCode;
	}
	

	/**
	 * Get the detailed message
	 * 
	 * @param cause Throwable
	 * @return buffer String
	 */
	private String getMessageStackString(final Throwable cause) {
		StringWriter writer = new StringWriter();
		PrintWriter printWriter = new PrintWriter(writer);
		cause.printStackTrace(printWriter);
		
		StringBuffer buffer = writer.getBuffer();
		return buffer.toString();		
	}
}
