package com.socgen.bip.divaPrjt.util;

public class ReportConstants {

	
	public static final String BIP = "BIP";
	
	
	public static final String DIVA_PRJT_BATCH ="DIVA_PRJT_BATCH";
	
	public static final String MAIN_METHOD_START = "Main Method <<Start>>";
	
	public static final String MAIN_METHOD_END = "Main Method <<End>>";
	
	public static final String APP_CONTEXT = "launch-context.xml";
	
	public static final String EXCP_OCCURED_IN = "Exception Occured in ";
	
	public static final String JOB_LAUNCHER = "jobLauncher";
	
	public static final String START = " START";
	
	public static final String END = " END";
	
	public static final String INSIDE_READER = "Inside reader";
	
	public static final String EXCEP_OCC_IN_READER  = "Exception Occured in Reader ";
	
	public static final String READERERRORCODE = "READERERRORCODE";	
	
	public static final String INSIDE_WRITER  = "Inside writer";
	
	public static final String EXCEP_OCC_IN_WRITER = "Exception Occured in Writer ";
	
	public static final String WRITERERRORCODE = "WRITERERRORCODE";
	
	public static final String NEXTLINE = "\n";	
}
