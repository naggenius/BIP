package com.socgen.bip.divaPrjt.util;

import java.util.ResourceBundle;


public final class ResourceBundleLoader {

	/**
	 * @param ResourceBundleLoader
	 */
	private ResourceBundleLoader(){
		
	}
	
	/**
     * Method helps to get ResourceBundle for resources.properties
     * @param  
     * @return ResourceBundle
     */
	private static ResourceBundle getResourceBundle(){
		ResourceBundle rb = null;
			rb = ResourceBundle.getBundle("resources");
		return rb;
	}
	
	/**
     * Method helps to get ResourceBundle value for the input Key 
     * @param   propertyKey String
     * @return String
     */
	public static String getValue(final String propertyKey){
		return getResourceBundle().getString(propertyKey);
	}
	
	/**
     * Method helps to get ResourceBundle value for the input Key 
     * @param propertyKey String
     * @param batch boolean
     * @return constant String
     */
	public static String getValue(String propertyKey, boolean batch){
		if(batch) {
			return ResourceBundle.getBundle("properties/db_config").getString(propertyKey);
		} else {
			return "";
		}
	}
}
