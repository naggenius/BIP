package com.socgen.bip.divaPrjt.util;

public class ExtractModal {

	
	private String icpi;
	private String ilibel;
	private String statut;
	private String datdem;
	private String cada;
	private String icodproj;
	
	public String getIcpi() {
		return icpi;
	}
	public void setIcpi(String icpi) {
		this.icpi = icpi;
	}
	public String getIlibel() {
		return ilibel;
	}
	public void setIlibel(String ilibel) {
		this.ilibel = ilibel;
	}
	public String getStatut() {
		return statut;
	}
	public void setStatut(String statut) {
		this.statut = statut;
	}
	public String getDatdem() {
		return datdem;
	}
	public void setDatdem(String datdem) {
		this.datdem = datdem;
	}
	public String getCada() {
		return cada;
	}
	public void setCada(String cada) {
		this.cada = cada;
	}
	public String getIcodproj() {
		return icodproj;
	}
	public void setIcodproj(String icodproj) {
		this.icodproj = icodproj;
	}
	
	
	
	


}
