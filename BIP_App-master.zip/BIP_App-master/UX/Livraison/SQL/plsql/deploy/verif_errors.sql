spool $TMPDIR/errors_compile.log;

select * from sys.user_errors;



exit;
