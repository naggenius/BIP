sqlplus -s $CONNECT_STRING << ! 
set head off 

TRUNCATE TABLE TMP_REJETMENS;

!`
